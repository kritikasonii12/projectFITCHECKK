const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { db, save, uid } = require('../data/store');
const auth = require('../middleware/auth');
const { JWT_SECRET } = auth;

const router = express.Router();

function genOtp() { return String(Math.floor(100000 + Math.random() * 900000)); }

// In-memory only — codes for signups/resets in progress, not persisted to disk
const pendingRegs = {};   // email -> { name, email, passwordHash, otp }
const pendingResets = {}; // email -> otp

// ---- Step 1 of registration: validate + generate a 2FA code ----
router.post('/register/start', (req, res) => {
  const { name, email, password } = req.body || {};
  if (!name || !email || !password) return res.status(400).json({ message: 'All fields required' });
  if (password.length < 6) return res.status(400).json({ message: 'Password needs 6+ characters' });
  const key = email.toLowerCase();
  if (db.users.find(u => u.email === key)) return res.status(409).json({ message: 'Email already registered' });

  const passwordHash = bcrypt.hashSync(password, 10);
  const otp = genOtp();
  pendingRegs[key] = { name, email: key, passwordHash, otp, createdAt: Date.now() };
  console.log(`[Fitcheck 2FA] Verification code for ${key}: ${otp}`);
  // Demo note: no email/SMS service is wired up, so the code is returned here
  // so the UI can show it. Swap this for Nodemailer/Twilio in production and
  // stop returning demoOtp.
  res.json({ message: 'Verification code generated', demoOtp: otp });
});

// ---- Step 2 of registration: verify the code, actually create the account ----
router.post('/register/verify', (req, res) => {
  const { email, code } = req.body || {};
  const key = (email || '').toLowerCase();
  const pending = pendingRegs[key];
  if (!pending) return res.status(400).json({ message: 'No pending registration for that email' });
  if (pending.otp !== code) return res.status(401).json({ message: 'Incorrect code' });

  const user = { id: uid(), name: pending.name, email: pending.email, passwordHash: pending.passwordHash, twoFA: true, createdAt: Date.now() };
  db.users.push(user); save();
  delete pendingRegs[key];

  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.status(201).json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

router.post('/login', (req, res) => {
  const { email, password } = req.body || {};
  const user = db.users.find(u => u.email === (email || '').toLowerCase());
  if (!user || !bcrypt.compareSync(password || '', user.passwordHash)) {
    return res.status(401).json({ message: 'Incorrect email or password' });
  }
  const token = jwt.sign({ userId: user.id }, JWT_SECRET, { expiresIn: '7d' });
  res.json({ token, user: { id: user.id, name: user.name, email: user.email } });
});

router.get('/me', auth, (req, res) => {
  const user = db.users.find(u => u.id === req.userId);
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json({ id: user.id, name: user.name, email: user.email });
});

router.post('/forgot/start', (req, res) => {
  const { email } = req.body || {};
  const key = (email || '').toLowerCase();
  const user = db.users.find(u => u.email === key);
  if (!user) return res.status(404).json({ message: 'No account found for that email' });
  const otp = genOtp();
  pendingResets[key] = otp;
  console.log(`[Fitcheck reset] Reset code for ${key}: ${otp}`);
  res.json({ message: 'Reset code generated', demoOtp: otp });
});

router.post('/forgot/verify', (req, res) => {
  const { email, code } = req.body || {};
  const key = (email || '').toLowerCase();
  if (pendingResets[key] !== code) return res.status(401).json({ message: 'Incorrect code' });
  res.json({ message: 'Code verified' });
});

router.post('/forgot/reset', (req, res) => {
  const { email, code, password } = req.body || {};
  const key = (email || '').toLowerCase();
  if (pendingResets[key] !== code) return res.status(401).json({ message: 'Incorrect or expired code' });
  if (!password || password.length < 6) return res.status(400).json({ message: 'Password needs 6+ characters' });
  const user = db.users.find(u => u.email === key);
  if (!user) return res.status(404).json({ message: 'User not found' });
  user.passwordHash = bcrypt.hashSync(password, 10);
  save();
  delete pendingResets[key];
  res.json({ message: 'Password updated' });
});

module.exports = router;
